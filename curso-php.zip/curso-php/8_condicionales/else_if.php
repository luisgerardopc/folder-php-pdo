<?php
   $numero = -10;
   if($numero > 0){
      echo 'El número es positivo.';
   }else if($numero < 0){
      echo 'El número es negativo.';
   }else{
      echo 'El número es cero.';
   }
?>