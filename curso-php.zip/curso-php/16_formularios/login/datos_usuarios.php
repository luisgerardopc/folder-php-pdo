<?php
	define('USUARIO', 'pepito');
	define('CONTRASENA', '1234');
?>