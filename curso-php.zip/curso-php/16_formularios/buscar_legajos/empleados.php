﻿<?php
    $empleados = array(
        '10001' => array(
            'nombre' => 'Alejandro',
            'apellido' => 'Calvo',
            'sector' => 'Diseño'
        ),
        '10002' => array(
            'nombre' => 'Ignacio',
            'apellido' => 'Celestino',
            'sector' => 'Programación'
        ),
        '10003' => array(
            'nombre' => 'Marina',
            'apellido' => 'Oliver',
            'sector' => 'DB Master'
        )
    );
?>