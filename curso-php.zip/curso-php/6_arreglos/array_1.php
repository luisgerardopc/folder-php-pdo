<?php
   $articulos = array();
   $articulos[] = 'Birome';
   $articulos[] = 'Cuaderno';
   $articulos[] = 'Resaltador';
   $articulos[] = 'Crayones';
   $articulos[] = 'Corrector';
   echo $articulos[0];//Devuelve el valor Birome.
?>
