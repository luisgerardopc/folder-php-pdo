<?php
   $personas = array(
   array(
      'nombre' => 'Luis',
      'apellido' => 'Peña',
      'edad' => 37,
      'programador' => true
   ),
   array(
      'nombre' => 'José',
      'apellido' => 'Benvenuto',
      'edad' => 20,
      'programador' => true
   ),
   array(
      'nombre' => 'Carlos',
      'apellido' => 'Martínez',
      'edad' => 32,
      'programador' => false
   )
 );
 
 echo $personas[1]['edad'];//Esto devolverá 20
?>