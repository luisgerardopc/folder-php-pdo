<?php
   $numero = 3;
   switch ($numero) {
      case 1:
         echo 'Transferido a servicio técnico';
         break;
      case 2:
         echo 'Transferido a ventas';
         break;
      case 3:
         echo 'Transferido a consultas';
         break;
      case 4:
         echo 'Transferido a reclamos';
         break;
      default:
         echo 'El código ingresado es incorrecto';
   }
?>