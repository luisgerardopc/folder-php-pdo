<?php
   $persona = array(
      'nombre' => 'Luis',
      'apellido' => 'Peña',
      'edad' => 37,
      'programador' => true
   );
   echo $persona['nombre'];//Devuelve Luis.
?>