<?php
   $nombre = 'Fernando';
   echo $nombre;
   echo '<br />';
   $nombre = 'Gonzalo';
   echo $nombre;
   echo '<br />';
?>
