<?php
   $nombre = 'Fernando';
   $apellido = 'Gaitan';
   $nombre_completo = $nombre . ' ' . $apellido;
   echo $nombre_completo;
?>
