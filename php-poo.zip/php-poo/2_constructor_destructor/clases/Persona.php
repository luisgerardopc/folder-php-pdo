<?php
	class Persona{
			public $nombre;
			public $apellido;
			public $edad;
			
			//Constructor
			public function __construct($nombre, $apellido, $edad) {
				$this->nombre = $nombre;
				$this->apellido = $apellido;
				$this->edad = $edad;
			}
			
			public function __destruct() {
       		//echo 'Objeto destruido';
       	}
			
			//Definicion de funciones
			public function saludar() {
				return 'Hola soy ' . $this->nombre . ' ' . ' y mi apellidos es ' . $this->apellido . ' ' . ' y tengo ' . $this->edad . 'años.';
			}					
			
			//echo 'se acaba de crear el objeto persona';
			
		}					
?>