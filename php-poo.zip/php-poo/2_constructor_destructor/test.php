<?php
	require_once 'clases/Persona.php';
	//$persona = new Persona();
	$persona = new Persona('Luis', 'Peña', 27);
	
	//llamadas a la funcion
	echo $persona->saludar();
	//Destruimos el objeto.
 	unset($persona);
	
?>
