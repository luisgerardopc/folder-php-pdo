<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php 

/**
* 
*/
class Persona
{
	
	public $nom;

	public $ape;

	public $ced;

	public $car;



	public function __construct($a, $b, $c, $d)
	{
		 $this->nom= $a;
		 $this->ape= $b;
		 $this->ced= $c;
		 $this->car= $d;
	}

}







 ?>