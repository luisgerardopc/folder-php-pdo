<?php
	require_once 'clases/Persona.php';
	//Creacion del Objeto
	$persona = new Persona();
	//Seteamos las propiedades
	$persona->nombre = 'Luis';
	$persona->apellido = 'Peña';
	$persona->edad = 37;
	
	//Presentamos en Pantalla
	echo 'Nombre:' . $persona->nombre . '<br />';
	echo 'Apellido:' . $persona->apellido . '<br />';
	echo 'Edad:' . $persona->edad . '<br />';
	
	//Haciendo uso de la funcion saludar
	echo 'Funcion Saludar <br/>';
	echo $persona->saludar();
?>